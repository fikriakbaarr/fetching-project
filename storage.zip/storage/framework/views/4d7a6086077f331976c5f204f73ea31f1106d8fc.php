
<?php $__env->startSection('title'); ?>
    Store About page
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container text-center">
        <img src="/images/products-tatakan-gelas" class="img-fluid mt-4" alt="..." />
    </div>
    <div class="container">
        <div class="row">
            <div class="col mt-4">
                <h1 class="text-center">Tentang kami</h1>
                <p class="text-center">
                    adalah sebuah toko penjualan buah tangan untuk boy band kpop
                </p>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="col mt-4">
            <h2 class="text-center">Panduan pembelian</h2>
            <p class="text-center">
                hallo sahabat kipop, disini mimin akan <br />
                menjelaskan tentang langkah langkah yang harus <br />
                dilewati ketika melakukan pembelian.
            </p>
            <p class="text-center">
                baik tidak perlu berlama lama, <br />
                mari simak langkah labgkah nya dengan benar ya <br />
                1. kita akan melakukan login ke dalam web facthing <br />
                2. jika belum memiliki akun maka silanhkan melakukan pendaftaran
                <br />
                3. jika sudah memenuhi syarat diatas, maka akan masuk ke halaaman
                beranga <br />
                4. pilih barang yang disukai <br />
                5. masuk ke halaman detail
            </p>

            <div class="col">
                <p></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bwastore-laravel\resources\views/pages/about.blade.php ENDPATH**/ ?>