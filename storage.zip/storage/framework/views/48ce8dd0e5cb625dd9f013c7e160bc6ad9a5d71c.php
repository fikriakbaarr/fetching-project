    <footer>
      <div class="container">
        <div class="row">
          <div class="col-12 text-center">
            <p class="pt-4 pb-2">2022 Fecthing project. All Rights Reserved.</p>
          </div>
        </div>
      </div>
    </footer><?php /**PATH C:\laragon\www\bwastore-laravel\resources\views/includes/footer.blade.php ENDPATH**/ ?>