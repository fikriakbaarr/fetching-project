
<?php $__env->startSection('title'); ?>
    Store Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title">Dashboard</h2>
                <p class="dashboard-subtitle">
                    Fetching project membuat anda lebih dekat dengan idola!
                </p>
            </div>
            <div class="dashboard-content">


            </div>
            <div class="row mt-3">
                <div class="col-12 mt-2">
                    
                    
                    
                    
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bwastore-laravel\resources\views/pages/dashboard.blade.php ENDPATH**/ ?>