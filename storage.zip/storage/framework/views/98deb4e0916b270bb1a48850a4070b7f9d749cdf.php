
<?php $__env->startSection('title'); ?>
    Store Dashboard Transaction Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="section-content section-dashboard-home" data-aos="fade-up">
        <div class="container-fluid">
            <div class="dashboard-heading">
                <h2 class="dashboard-title"><?php echo e($transaction->code); ?></h2>
                <p class="dashboard-subtitle">
                    Transaksi detail
                </p>
            </div>
            <div class="dashboard-content" id="transactionDetails">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-12 col-md-4">
                                        <img src="<?php echo e(Storage::url($transaction->product->galleries->first()->photos ?? '')); ?>"
                                            alt="" class="w-100 mb-3" />
                                    </div>
                                    <div class="col-12 col-md-8">
                                        <div class="row">

                                            <div class="col-12 col-md-6">
                                                <div class="product-title">Nama pembeli</div>
                                                <div class="product-subtitle">
                                                    <?php echo e($transaction->transaction->user->name); ?>

                                                </div>
                                            </div>

                                            <div class="col-12 col-md-6">
                                                <div class="product-title">Nama produk</div>
                                                <div class="product-subtitle">
                                                    <?php echo e($transaction->product->name); ?>

                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="product-title">
                                                    Tanggal transaksi
                                                </div>
                                                <div class="product-subtitle">
                                                    <?php echo e($transaction->created_at); ?>

                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="product-title">Status pembayaran</div>
                                                <div class="product-subtitle text-danger">
                                                    <?php echo e($transaction->transaction->transaction_status); ?>

                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="product-title">Jumlah harga</div>
                                                <div class="product-subtitle">
                                                    Rp.<?php echo e(number_format($transaction->transaction->total_price)); ?>

                                                </div>
                                            </div>
                                            <div class="col-12 col-md-6">
                                                <div class="product-title">Nomor telepon</div>
                                                <div class="product-subtitle">
                                                    <?php echo e($transaction->transaction->user->phone_number); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <form action="<?php echo e(route('dashboard-transaction-update', $transaction->id)); ?>" method="POST"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-12 mt-4">
                                            <h5>
                                                informasi alamat
                                            </h5>
                                            <div class="row">
                                                <div class="col-12 col-md-6">
                                                    <div class="product-title">Alamat</div>
                                                    <div class="product-subtitle">
                                                        <?php echo e($transaction->transaction->user->addres); ?>

                                                    </div>
                                                </div>

                                                <div class="col-12 col-md-6">
                                                    <div class="product-title">
                                                        Provinsi
                                                    </div>
                                                    <div class="product-subtitle">
                                                        <?php echo e(App\Models\Province::find($transaction->transaction->user->provinces_id)->name); ?>

                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <div class="product-title">Kota</div>
                                                    <div class="product-subtitle">
                                                        <?php echo e(App\Models\Regency::find($transaction->transaction->user->regencies_id)->name); ?>

                                                    </div>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <div class="product-title">Kode pos</div>
                                                    <div class="product-subtitle">
                                                        <?php echo e($transaction->transaction->user->zip_code); ?></div>
                                                </div>

                                                

                                                </template>
                                            </div>
                                        </div>
                                    </div>
                                    
                            </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('addon-script'); ?>
    <script src="/vendor/vue/vue.js"></script>
    <script>
        var transactionDetails = new Vue({
            el: "#transactionDetails",
            data: {
                status: "<?php echo e($transaction->shipping_status); ?>",
                resi: "<?php echo e($transaction->resi); ?>",
            },
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\bwastore-laravel\resources\views/pages/dashboard-transactions-details.blade.php ENDPATH**/ ?>